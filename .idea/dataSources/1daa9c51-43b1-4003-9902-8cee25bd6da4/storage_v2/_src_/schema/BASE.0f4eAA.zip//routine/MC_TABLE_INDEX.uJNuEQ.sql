create function mc_table_index(towner    in varchar2,
                                          tname     in varchar2,
                                          tind_name in varchar2)
  return varchar2 as

  v_tmp   varchar2(1000);
  v_num   number(10);
  v_count number(10) := 0;

begin
  select count(*)
    into v_num
    from all_ind_columns t, all_indexes i
   where t.index_owner = i.owner
     and towner = t.index_owner
     and t.table_name = i.table_name
     and tname = t.table_name
     and t.index_name = i.index_name
     and t.index_name = tind_name
     AND i.owner NOT LIKE '%SYS%';
  for ind in (select t.*
                from all_ind_columns t, all_indexes i
               where t.index_owner = i.owner
                 and towner = t.index_owner
                 and t.table_name = i.table_name
                 and tname = t.table_name
                 and t.index_name = i.index_name
                 and t.index_name = tind_name
                 AND i.owner NOT LIKE '%SYS%'
               order by t.column_position)
  loop
    v_tmp   := v_tmp || ind.column_name || ' ASC';
    v_count := v_count + 1;
    if (v_count < v_num)
    then
      v_tmp := v_tmp || ',';
    end if;
  end loop;
  return v_tmp;
end mc_table_index;

/

