create function mc_table_pk(towner    in varchar2,
                                       tname     in varchar2,
                                       tcon_name in varchar2)
  return varchar2 as
  v_tmp   varchar2(3000);
  v_num   number(20);
  v_count number(20) := 0;
begin
  select count(*)
    into v_num
    from all_cons_columns cu,
         all_constraints au
   where cu.constraint_name = au.constraint_name
     and tcon_name = au.constraint_name
     and au.constraint_type = 'P'
     and au.table_name = tname
     and au.owner = towner
     and towner = cu.owner;

  for ind in (select cu.*
                from all_cons_columns cu,
                     all_constraints au
               where cu.constraint_name = au.constraint_name
                 and tcon_name = au.constraint_name
                 and au.constraint_type = 'P'
                 and au.table_name = tname
                 and au.owner = towner
                 and towner = cu.owner
               ORDER BY cu.position)
  loop
    v_tmp   := v_tmp || ind.column_name;
    v_count := v_count + 1;
    if (v_count < v_num)
    then
      v_tmp := v_tmp || ',';
    end if;
  end loop;
  return(v_tmp);
end mc_table_pk;

/

