create function mc_table_columns_info(towner in varchar2,
                                                   tname  in varchar2)
  return varchar2 as

  v_tmp   varchar2(3000);
  v_count number(20) := 0;
  v_num   number(20);
begin
  select count(*)
    into v_num
    from ALL_tab_columns
   where table_name = tname
     and owner = towner;
  for col in (select *
                from ALL_tab_columns
               where table_name = tname
                 and owner = towner
               order by column_id) loop
    if (col.data_type = 'DATE' or col.data_type = 'CLOB' or
       col.data_type = 'BLOB') then
      v_tmp := v_tmp || col.column_name || ' ' || col.data_type;
    elsif (col.data_type = 'NUMBER' or col.data_type = 'FLOAT') then
      if (col.data_precision is not null) then
        v_tmp := v_tmp || col.column_name || ' ' || col.data_type || '(' ||
                 col.data_precision || ')';
      else
        v_tmp := v_tmp || col.column_name || ' ' || col.data_type;
      end if;
    else
      v_tmp := v_tmp || col.column_name || ' ' || col.data_type || '(' ||
               col.data_length || ')';
    end if;

    if (col.default_length > 0) then
      v_tmp := v_tmp || ' default ' || col.data_default;
    end if;

    if (col.nullable = 'N') then
      v_tmp := v_tmp || ' not null';
    end if;

    v_count := v_count + 1;
    if (v_count < v_num) then
      v_tmp := v_tmp || ',';
    end if;
  end loop;
  return replace(v_tmp, chr(10), '');
end mc_table_columns_info;

/

